def f():
    print("Kotya")