from setuptools import setup

setup(
    name='packageForLab2',
    version='0.1',
    description='Package for lab 2',
    url='',
    install_requires=['pandas<1.0'],
    packages=['myPackage'],
)